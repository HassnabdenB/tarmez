package com.example.videosecret;

import android.app.*;
import android.os.*;
import android.content.*;
import android.text.*;
import android.widget.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;
import android.util.Base64;

public class MainActivity extends Activity {
    // ضع هنا عنوان صفحة الوسيط المستضافة HTTPS بعد نشرها.
    private static final String BASE_URL = "https://YOUR-DOMAIN.example/";

    EditText video,message,password,decodeUrl,decodePassword;
    TextView output,result;

    String b64(byte[] x){ return Base64.encodeToString(x,Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING); }
    byte[] ub64(String s){ return Base64.decode(s,Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING); }

    byte[] sha(String s) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        return md.digest(s.getBytes(StandardCharsets.UTF_8));
    }

    String pack(String v,String m,String p) throws Exception {
        // For the demo project, payload is URL-safe Base64 JSON-like text.
        // Password mode hashes the password into a verifier field.
        String pv=p.isEmpty() ? "" : b64(sha(p));
        String raw="u="+b64(v.getBytes(StandardCharsets.UTF_8))+
                   "&m="+b64(m.getBytes(StandardCharsets.UTF_8))+
                   "&p="+pv;
        return b64(raw.getBytes(StandardCharsets.UTF_8));
    }

    String unpack(String token,String pass) throws Exception {
        String raw=new String(ub64(token),StandardCharsets.UTF_8);
        String[] parts=raw.split("&", -1);
        String u="",m="",pv="";
        for(String x:parts){
            int i=x.indexOf('=');
            if(i<0)continue;
            String k=x.substring(0,i), val=x.substring(i+1);
            if(k.equals("u"))u=new String(ub64(val),StandardCharsets.UTF_8);
            if(k.equals("m"))m=new String(ub64(val),StandardCharsets.UTF_8);
            if(k.equals("p"))pv=val;
        }
        if(!pv.isEmpty() && !pv.equals(b64(sha(pass)))) throw new SecurityException();
        return "الرسالة:\n"+m+"\n\nالفيديو:\n"+u;
    }

    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        video=findViewById(R.id.video); message=findViewById(R.id.message);
        password=findViewById(R.id.password); decodeUrl=findViewById(R.id.decodeUrl);
        decodePassword=findViewById(R.id.decodePassword); output=findViewById(R.id.output);
        result=findViewById(R.id.result);

        findViewById(R.id.create).setOnClickListener(v -> {
            try{
                String u=video.getText().toString().trim();
                if(!u.startsWith("http://")&&!u.startsWith("https://")) { output.setText("أدخل رابط فيديو صحيح."); return; }
                String token=pack(u,message.getText().toString(),password.getText().toString());
                output.setText(BASE_URL+"?v="+token);
            }catch(Exception e){ output.setText("حدث خطأ."); }
        });

        findViewById(R.id.copy).setOnClickListener(v -> {
            ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Video Secret",output.getText()));
            Toast.makeText(this,"تم النسخ",Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.decode).setOnClickListener(v -> {
            try{
                String u=decodeUrl.getText().toString().trim();
                int q=u.indexOf("?v=");
                if(q<0) throw new Exception();
                result.setText(unpack(u.substring(q+3),decodePassword.getText().toString()));
            }catch(Exception e){ result.setText("تعذر فك الرابط أو كلمة المرور غير صحيحة."); }
        });
    }
}